#' @title Application of the stem-cycle approach to calculate cyclic phases and tree-level phase statistics.
#'
#' @description This function analyses dendrometer data using the stem-cycle approach
#' (Downs et al. 1999; Deslauriers et al. 2011). It defines three phases:
#' 1) shrinkage, when the dendrometer reading is lower than the previous reading,
#' 2) expansion, when the dendrometer reading is higher than or equal to the previous
#' reading but does not exceed the previous maximum, and 3) increment, when the
#' dendrometer reading is higher than the previous maximum. The function also
#' calculates phase-level statistics and adds the analysed tree identifier to both
#' output tables.
#'
#' @references Deslauriers A, Rossi S, Turcotte A, Morin H, Krause C (2011) A three-step
#' procedure in SAS to analyze the time series from automatic dendrometers.
#' Dendrochronologia 29:151-161. \doi{10.1016/j.dendro.2011.01.008}
#'
#' @references Downes G, Beadle C, Worledge D (1999) Daily stem growth patterns in
#' irrigated Eucalyptus globulus and E. nitens in relation to climate.
#' Trees 14:102-111. \doi{10.1007/PL00009752}
#'
#' @param df Dataframe with the first column containing date and time in the format
#'   \code{yyyy-mm-dd HH:MM:SS}. It should contain data with constant temporal
#'   resolution for best results.
#'
#' @param TreeNum Numeric value indicating the tree to be analysed. For example,
#'   \code{TreeNum = 1} refers to the first dendrometer data column after the
#'   timestamp column, i.e. \code{df[[2]]}.
#'
#' @param smoothing Numeric value from 1 to 24 indicating the smoothing window in
#'   hours. Default is \code{NULL} for no smoothing. The function
#'   \code{\link[pspline:smooth.Pspline]{smooth.Pspline}} is used for smoothing.
#'
#' @return A list of two dataframes. The first dataframe, \code{SC_cycle}, contains
#'   cyclic phases and their statistics. The second dataframe, \code{SC_phase},
#'   contains the timestamp-level phase assignment. Both tables include a \code{Tree}
#'   column derived from the dendrometer column selected by \code{TreeNum}.
#'
#' The contents of \code{SC_cycle} are:
#' \tabular{llll}{
#' \strong{Columns}\tab\tab \strong{Description}\cr
#' \code{Tree}\tab\tab Analysed dendrometer series name derived from \code{df}.\cr
#' \code{Phases}\tab\tab Cyclic phases. 1, 2, and 3 for shrinkage, expansion, and increment respectively.\cr
#' \code{Start}\tab\tab Time when the corresponding phase starts.\cr
#' \code{End}\tab\tab Time when the corresponding phase ends.\cr
#' \code{Duration_h}\tab\tab Duration of the corresponding phase in hours.\cr
#' \code{Duration_m}\tab\tab Duration of the corresponding phase in minutes.\cr
#' \code{Magnitude}\tab\tab Radial/circumferential change during the corresponding phase in millimeters.\cr
#' \code{rate}\tab\tab Rate of radial/circumferential change in micrometers per hour.\cr
#' \code{DOY}\tab\tab Day of year for the corresponding phase.\cr
#' }
#'
#' The contents of \code{SC_phase} are:
#' \tabular{llll}{
#' \strong{Columns}\tab\tab \strong{Description}\cr
#' \code{Tree}\tab\tab Analysed dendrometer series name derived from \code{df}.\cr
#' \code{TIME}\tab\tab Timestamp.\cr
#' \code{dm}\tab\tab Dendrometer measurement of the selected tree.\cr
#' \code{Phases}\tab\tab Timestamp-level phase assignment.\cr
#' }
#'
#' @examples
#' library(dendRoAnalyst)
#' data(gf_nepa17)
#' sc.phase <- phase.sc(df = gf_nepa17, TreeNum = 1, smoothing = 12)
#' head(sc.phase$SC_cycle, 10)
#' head(sc.phase$SC_phase, 10)
#'
#' @export
phase.sc <- function(df, TreeNum, smoothing = NULL) {

  # -------------------------------
  # Basic checks and tree identifier
  # -------------------------------
  if (!is.numeric(TreeNum) || length(TreeNum) != 1 || is.na(TreeNum) || TreeNum < 1) {
    stop("TreeNum must be a single positive numeric value.")
  }

  if (TreeNum > (ncol(df) - 1)) {
    stop("The tree number is not valid for the provided dataset.")
  }

  tree_name <- names(df)[TreeNum + 1]
  if (is.null(tree_name) || is.na(tree_name) || tree_name == "") {
    tree_name <- paste0("Tree", TreeNum)
  }

  # -------------------------------
  # Function to calculate phases
  # -------------------------------
  phase_cal <- function(y) {
    all_max <- cummax(y)
    all_max_diff <- diff(all_max)
    y_diff <- diff(y)

    phases <- sapply(seq_along(all_max_diff), function(i) {
      if (is.na(all_max_diff[i]) || is.na(y_diff[i])) {
        ph <- NA_integer_
      } else if (all_max_diff[i] > 0) {
        ph <- 3L
      } else if (y_diff[i] >= 0) {
        ph <- 2L
      } else {
        ph <- 1L
      }
      return(ph)
    })

    return(as.integer(phases))
  }

  # -------------------------------
  # Function to calculate phase stats
  # -------------------------------
  phase_sats <- function(dm_data, y, tree_name) {
    ph_diff <- c(0, diff(y))
    change_idx <- which(ph_diff != 0 & !is.na(ph_diff))

    dy <- lubridate::yday(c(dm_data$TIME[1], dm_data$TIME[change_idx]))
    ph <- c(y[1], y[change_idx])

    magn <- c(dm_data$dm[1], dm_data$dm[change_idx], dm_data$dm[nrow(dm_data)])
    magn <- diff(magn)

    strt_t <- c(dm_data$TIME[1], dm_data$TIME[change_idx])
    end_t <- c(strt_t[2:length(strt_t)], dm_data$TIME[nrow(dm_data)])

    dur_h <- as.numeric(difftime(end_t, strt_t), units = "hours")
    dur_m <- as.numeric(difftime(end_t, strt_t), units = "mins")

    out <- tibble::tibble(
      Tree = tree_name,
      Phases = ph,
      Start = strt_t,
      End = end_t,
      Duration_h = dur_h,
      Duration_m = dur_m,
      Magnitude = magn,
      rate = magn * 1000 / dur_h,
      DOY = dy
    )

    out <- dplyr::mutate(
      out,
      rate = dplyr::if_else(is.finite(rate), rate, NA_real_)
    )

    return(out)
  }

  # -------------------------------
  # Function to calculate temporal resolution
  # -------------------------------
  reso_den <- function(input_time) {
    time1 <- input_time
    reference <- time1[1]
    time_min <- as.integer(difftime(time1, reference, units = "mins"))
    diff_time <- diff(time_min)
    diff2_time <- unique(diff_time)
    reso <- mean(diff2_time, na.rm = TRUE)

    if (length(diff2_time) > 1) {
      print(diff2_time)
      warning(
        "Warning: The temporal resolution of dendrometer data is not consistent. ",
        "For better results, please use dendrometer data with consistent resolution. ",
        "There may be NA values in the dataset.",
        call. = FALSE
      )
    }

    return(round(reso))
  }

  # -------------------------------
  # Prepare input
  # -------------------------------
  if (!inherits(df[[1]], "Date") && !inherits(df[[1]], "POSIXct")) {
    df[[1]] <- lubridate::ymd_hms(df[[1]])
  }

  dm_data <- tibble::as_tibble(df) %>%
    dplyr::select(c(1, TreeNum + 1)) %>%
    dplyr::rename(
      TIME = 1,
      dm = 2
    )

  r.denro <- reso_den(dm_data$TIME)
  sf <- smoothing

  # -------------------------------
  # Optional smoothing for phase assignment
  # -------------------------------
  if (is.null(sf)) {
    y_sm <- dm_data$dm
  } else {
    if (!is.numeric(sf) || length(sf) != 1 || is.na(sf) || sf > 24 || sf < 1) {
      stop("smoothing must be a single numeric value between 1 and 24 hours.")
    }

    warning(
      paste0(
        "You are applying smoothing to raw DM data. ",
        "The smoothing value is ", sf, " hour(s)."
      ),
      call. = FALSE
    )

    spar2 <- (60 / r.denro) * sf
    sm <- pspline::smooth.Pspline(1:nrow(dm_data), dm_data$dm, spar = spar2)
    y_sm <- as.numeric(sm$ysmth)
  }

  y <- phase_cal(y_sm)
  ph_st <- phase_sats(dm_data, y, tree_name = tree_name)

  dm_data <- dm_data %>%
    dplyr::mutate(
      Tree = tree_name,
      Phases = c(NA_integer_, y)
    ) %>%
    dplyr::select(Tree, TIME, dm, Phases)

  out <- list(
    SC_cycle = ph_st,
    SC_phase = tibble::as_tibble(dm_data)
  )

  attr(out$SC_cycle, "Tree") <- tree_name
  attr(out$SC_phase, "Tree") <- tree_name

  class(out) <- "SC_output"
  return(out)
}
