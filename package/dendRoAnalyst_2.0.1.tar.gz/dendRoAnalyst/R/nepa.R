#' @title Dendrometer data from Kathmandu
#' @description Dendrometer data from two Chir pine (\emph{Pinus roxburghii})
#'   trees in Kathmandu, Nepal, recorded with band dendrometers at hourly
#'   resolution from May 2016 to December 2017. The values are stem
#'   circumference variations in mm.
#' @format A data frame with 14543 rows and 3 variables:
#' \describe{
#'   \item{\code{Time}}{POSIXct; time of data recording in Nepal Standard Time
#'     (NPT, UTC+05:45), stored with the time zone \code{"Asia/Kathmandu"}.}
#'   \item{\code{T2}}{double; reading of the first tree (mm).}
#'   \item{\code{T3}}{double; reading of the second tree (mm).}
#'}
"nepa"
