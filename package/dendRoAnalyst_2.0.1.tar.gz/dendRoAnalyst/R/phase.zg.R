#' @title Apply the Zero-Growth (ZG) approach to segment dendrometer data into TWD/GRO phases
#'
#' @description
#' Implements the Zero-Growth approach (Zweifel et al., 2016) on a single
#' dendrometer series to (i) classify each timestamp into \strong{tree water deficit}
#' (TWD; reversible shrinkage/expansion) or \strong{growth} (GRO; irreversible
#' expansion), (ii) summarize each contiguous phase (start/end, duration,
#' magnitude, rates, TWD statistics), and (iii) optionally smooth the raw
#' series prior to phase assignment to reduce spurious phase flips.
#'
#' The growth line is computed as the running cumulative maximum of the
#' (raw or smoothed) dendrometer series. TWD is defined as the vertical
#' distance between the growth line and the observed measurement.
#'
#' @details The compressed event index is \code{ABr.value = log10(1 + ABr.value.raw / 0.01)}. The fixed scale 0.01 is shared across trees and sites. \code{ABr.value.log1p} remains an alias of this new value; \code{ABr.value.pct} remains 100 times the raw value. Recompute older saved results to obtain the new columns.
#'
#' \strong{Phase assignment.}
#' Let \eqn{y_t} be the dendrometer measurement (raw or smoothed). The growth
#' line is \eqn{g_t=\max_{s\le t}(y_s)}. Points with \eqn{y_t = g_t} are labeled
#' \strong{GRO} (phase = 2). Points with \eqn{y_t < g_t} are labeled \strong{TWD}
#' (phase = 1). Contiguous runs of identical labels are summarized into
#' individual phases.
#'
#' \strong{Summaries per phase (ZG_cycle).}
#' For each phase, the function returns:
#' \itemize{
#'   \item \code{Phases} (1 = TWD, 2 = GRO)
#'   \item \code{Start}, \code{End} (\code{POSIXct})
#'   \item \code{Duration_h} (hours)
#'   \item \code{Magnitude} (mm): for GRO only, computed from the \emph{growth line}
#'         as \eqn{\Delta g = g_{\mathrm{end}}-g_{\mathrm{start}}}; \code{NA} for TWD
#'   \item \code{rate} (\eqn{\mu}m/h): \code{Magnitude * 1000 / Duration_h} (GRO only)
#'   \item \code{max.twd} (mm), \code{Max.twd.time} (\code{POSIXct}): peak TWD and its time (TWD only)
#'   \item \code{Avg.twd} (mm), \code{STD.twd} (mm): mean and SD of TWD within the phase (TWD only)
#'   \item \code{AUC.load} (mm*h): area under the TWD curve from phase start to \code{Max.twd.time} (TWD only)
#'   \item \code{AUC.total} (mm*h): area under the full TWD curve across the phase (TWD only)
#'   \item \code{AUC.recovery} (mm*h): post-peak residual deficit area, calculated as \code{AUC.total - AUC.load} (TWD only)
#'   \item \code{DOY}: day-of-year of the phase start
#'   \item \code{ABr.value.raw}: peak-weighted event-burden index for TWD phases
#'         (ABr, from German \emph{absolute Baumreaktion}, absolute tree response),
#'         calculated as
#'         \deqn{ABr = twd.average.standardized \times max.twd.std \times duration.twd.days^{beta}}
#'         where \code{twd.average.standardized = Avg.twd / twd_reference},
#'         \code{max.twd.std = max.twd / twd_reference}, and
#'         \code{duration.twd.days = Duration_h / abr_duration_reference_h}.
#'         With the defaults \code{twd_reference = 1} (mm), \code{beta = 1},
#'         and \code{abr_duration_reference_h = 24}, the index is an
#'         average-intensity and peak-weighted burden that is numerically equal
#'         to \code{Avg.twd * max.twd * duration} with TWD in mm and duration in
#'         days. Returned as \code{NA} for GRO phases.
#' }
#'
#' \strong{Measurement unit.}
#' All TWD amplitudes, magnitudes, and ABr values are calculated in mm. Input
#' series recorded in another unit are converted to mm internally according to
#' \code{measurement_unit}, so that the default \code{twd_reference} of 1 mm
#' and the fixed scale of \code{ABr.value} apply to all inputs.
#'
#' \strong{Point-level output (ZG_phase).}
#' The second element returns the input time series augmented with:
#' \itemize{
#'   \item \code{Phases} (1/2), \code{TWD} (= \code{GRO - dm}), and \code{GRO} (growth line).
#' }
#'
#' \strong{Smoothing (optional).}
#' If \code{smoothing} is provided (hours), the function uses
#' \code{smooth_dm(..., method = "median_mean", window_hours = smoothing)} to create a
#' smoothed series used \emph{only} for phase assignment; all magnitudes and TWD
#' statistics are still computed against the \emph{original} \code{dm}. This reduces
#' short-lived phase flips due to noise. Valid range is 1–24 hours.
#'
#' \strong{Temporal resolution.}
#' The function auto-detects the median sampling interval (in minutes) to
#' parameterize smoothing. If multiple distinct intervals are detected, a
#' warning is emitted (results may be degraded if resolution is inconsistent).
#'
#' \strong{Notes & caveats.}
#' \itemize{
#'   \item Negative \code{Magnitude} values in GRO phases indicate residual noise or
#'         insufficient smoothing; a warning is issued.
#'   \item Very short phases may occur around local extrema; consider smoothing
#'         or post-filtering minimal run lengths upstream if needed.
#'   \item Ensure timestamps are regular (or nearly regular) for best results.
#' }
#'

#'
#' \strong{Daily drought-index output (ZG_drought).}
#' If \code{drought_indices = TRUE}, the returned list also contains
#' \code{ZG_drought}, a daily table with maximum daily shrinkage (\code{MDS}),
#' reference maximum daily shrinkage (\code{MDSmax}), normalized maximum daily
#' shrinkage (\code{MDSnorm}), pre-dawn tree water deficit (\code{TWDpredawn}),
#' and normalized pre-dawn tree water deficit (\code{TWDnorm}). These variables
#' follow the definitions used by Peters et al. (2025), where \code{MDSmax} is
#' calculated by default as the 99th percentile of vegetation-season MDS values.
#' The function calculates these parameters only; it does not reproduce the full
#' physiological threshold modelling workflow of Peters et al. (2025).
#'
#' \strong{Peak-weighted event-burden ABr output.}
#' The returned phase table uses a peak-weighted ABr by default. Mean and
#' maximum TWD are both standardized by a common TWD reference. The default
#' reference is fixed at \code{1} mm, so \code{twd.average.standardized =
#' Avg.twd / 1} and \code{max.twd.std = max.twd / 1}; this preserves absolute
#' amplitude differences among trees, species, and sites. The main index is
#' returned as \code{ABr.value.raw}:
#' \deqn{ABr.value.raw = twd.average.standardized \times max.twd.std \times (Duration_h / abr_duration_reference_h)^{beta}}
#' With the default \code{twd_reference = 1}, \code{abr_duration_reference_h = 24},
#' and \code{beta = 1}, the index is numerically equal to
#' \code{Avg.twd * max.twd * duration} (TWD in mm, duration in days) and gives
#' high values only to events that combine sustained average TWD, high maximum
#' TWD, and long duration. Setting \code{twd_reference = NULL} or
#' \code{"tree_mean"} standardizes both TWD terms by the tree-level mean
#' \code{Avg.twd} (\code{"tree_max"} by its maximum), which removes differences
#' in absolute TWD amplitude among trees; the index is then dimensionless apart
#' from the duration term.
#'
#' The AUC-derived columns \code{AUC.total}, \code{duration.twd.equiv_h}, and
#' \code{duration.twd.equiv_days} are still returned as diagnostics, but they
#' no longer control \code{ABr.value.raw}. Loading and recovery slope columns are
#' also retained as diagnostic descriptors.
#'
#' The percentage output \code{ABr.value.pct} is calculated as
#' \code{100 * ABr.value.raw}, and \code{ABr.value.log1p} is
#' \code{log10(1 + ABr.value.pct)}.
#'
#' @references
#' Zweifel R, Haeni M, Buchmann N, Eugster W (2016) Are trees able to grow in periods of stem shrinkage?
#' \emph{New Phytologist}, 211:839-849. \doi{10.1111/nph.13995}
#'
#' Peters RL et al. (2025) Normalized tree water deficit: an automated dendrometer
#' signal to quantify drought stress in trees. \emph{New Phytologist}.
#' \doi{10.1111/nph.70266}
#'
#' @param df A data frame with the \strong{first column} containing date-time
#'   (character, \code{POSIXct}, or \code{Date} convertible to \code{POSIXct} using
#'   \code{lubridate::ymd_hms}) and the \strong{subsequent columns} containing one or
#'   more dendrometer series at constant temporal resolution, in the unit given
#'   by \code{measurement_unit}.
#' @param measurement_unit Character. Unit of the dendrometer series in
#'   \code{df}: \code{"mm"} (default), \code{"um"} (micrometres), or
#'   \code{"cm"}. The series is converted to mm internally, and all outputs
#'   (including \code{ZG_phase$dm}) are returned in mm.
#' @param TreeNum Integer index of the dendrometer series column to analyze.
#'   For example, \code{TreeNum = 1} refers to \code{df[[2]]} (the first dm column after
#'   the time column).
#' @param smoothing \code{NULL} (default) for no smoothing, or a numeric value
#'   between 1 and 24 specifying the smoothing window in \strong{hours} used by
#'   \code{smooth_dm(method = "median_mean")} for phase labeling.
#' @param beta Numeric scalar giving the duration exponent for the peak-weighted
#'   event-burden ABr formula. Defaults to \code{1}. In the current formulation
#'   this is used as a fixed exponent for direct TWD phase duration.
#' @param abr_adaptive_beta Logical retained for backward compatibility.
#'   The current peak-weighted formulation does not use slope-adaptive beta
#'   for \code{ABr.value.raw}; loading/recovery slope variables are returned only as
#'   diagnostics. If \code{TRUE}, a warning is issued and the fixed \code{beta}
#'   is still used.
#' @param abr_duration_reference_h Positive numeric scalar used to scale
#'   direct phase duration \code{Duration_h} before applying \code{beta}. The
#'   default \code{24} expresses event duration in days.
#' @param twd_reference Reference (in mm) used to standardize both
#'   \code{Avg.twd} and \code{max.twd} in the ABr formula. The default is
#'   \code{1}, which means \code{twd.average.standardized = Avg.twd / 1} and
#'   \code{max.twd.std = max.twd / 1} and preserves absolute TWD-amplitude
#'   differences among trees, species, and sites. Use \code{NULL} or
#'   \code{"tree_mean"} to divide by the mean \code{Avg.twd} of all TWD phases
#'   in the analysed series. Use \code{"tree_max"} to divide by the maximum
#'   \code{Avg.twd} observed in the analysed tree. Alternatively, provide
#'   another single positive numeric value (in mm) as a common reference for
#'   several trees.
#' @param max_twd_reference Deprecated alias for \code{twd_reference}; kept
#'   for backward compatibility.
#' @param twd_max_reference Deprecated alias for \code{twd_reference}; kept
#'   for backward compatibility.
#' @param slope_load_reference Optional positive numeric scalar used to standardize
#'   \code{slope.load.twd}. If \code{NULL}, the mean loading slope of all TWD
#'   phases in the analysed series is used.
#' @param slope_recovery_reference Optional positive numeric scalar used to standardize
#'   \code{slope.recovery.twd}. If \code{NULL}, the mean recovery slope of all
#'   TWD phases in the analysed series is used.
#' @param drought_indices Logical. If \code{TRUE}, calculate and return the
#'   daily drought-index table \code{ZG_drought}. Defaults to \code{TRUE}.
#' @param predawn_hours Numeric vector of length two giving the pre-dawn hour
#'   window used for \code{TWDpredawn} and the pre-dawn maximum stem radius used
#'   in \code{MDS}. Defaults to \code{c(0, 6)}.
#' @param midday_hours Numeric vector of length two giving the midday hour window
#'   used for the midday minimum stem radius in \code{MDS} and \code{TWDmidday}.
#'   Defaults to \code{c(10, 16)}.
#' @param season_months Integer vector giving the months used to estimate
#'   \code{MDSmax}. Defaults to May-October, \code{5:10}.
#' @param mds_probability Numeric probability used to calculate \code{MDSmax}
#'   from vegetation-season MDS values. Defaults to \code{0.99}.
#' @param min_mds_n Integer. Minimum number of valid seasonal MDS values expected
#'   for a stable \code{MDSmax} estimate. A warning is issued below this value.
#'   Defaults to \code{30}.
#'
#' @return
#' A named list of class \code{"ZG_output"} with two or three tibbles:
#' \itemize{
#'   \item \code{ZG_cycle}: one row per contiguous phase with columns
#'         \code{Tree}, \code{Phases}, \code{Start}, \code{End}, \code{Duration_h}, \code{DOY},
#'         GRO columns \code{Magnitude} and \code{rate}, TWD columns
#'         \code{max.twd}, \code{Max.twd.time}, \code{Avg.twd}, \code{STD.twd},
#'         \code{AUC.load}, \code{AUC.total}, \code{AUC.recovery}, and optimized ABr
#'         columns \code{duration.twd.equiv_h}, \code{duration.twd.equiv_days},
#'         \code{duration.twd.days}, \code{max.twd.std},
#'         \code{twd.average.standardized},
#'         \code{loading.duration_h}, \code{recovery.duration_h},
#'         \code{slope.load.twd}, \code{slope.recovery.twd},
#'         \code{slope.load.twd.std}, \code{slope.recovery.twd.std},
#'         \code{recovery.slowness.std}, \code{slope.stress.std},
#'         \code{ABr.beta.event}, \code{ABr.value.raw}, \code{ABr.value.pct},
#'         and \code{ABr.value.log1p}.
#'   \item \code{ZG_phase}: point-level data with columns
#'         \code{TIME}, \code{dm}, \code{Phases}, \code{TWD}, \code{GRO}.
#'   \item \code{ZG_drought}: daily drought-index table returned when
#'         \code{drought_indices = TRUE}. Columns include \code{MDS},
#'         \code{MDSmax}, \code{MDSnorm}, \code{TWDpredawn}, and
#'         \code{TWDnorm}.
#' }
#'
#' @section Column definitions (ZG_cycle):
#' \describe{
#'   \item{Phases}{Integer; 1 = TWD (reversible shrinkage/expansion),
#'   2 = GRO (irreversible expansion).}
#'   \item{Start, End}{\code{POSIXct}; phase boundaries.}
#'   \item{Duration_h}{Numeric; phase duration in hours.}
#'   \item{Magnitude}{Numeric; GRO-only millimeter change of growth line across the phase. \code{NA} for TWD.}
#'   \item{rate}{Numeric; GRO-only rate in (\code{Magnitude*1000/Duration_h}).}
#'   \item{max.twd}{Numeric; peak TWD within the TWD phase.}
#'   \item{Max.twd.time}{\code{POSIXct}; time of \code{max.twd} within the TWD phase.}
#'   \item{AUC.load}{Numeric; pre-peak area under the TWD curve in mm*h, integrated from
#'   phase start to \code{Max.twd.time}.}
#'   \item{AUC.total}{Numeric; total area under the TWD curve in mm*h across the full TWD phase.}
#'   \item{AUC.recovery}{Numeric; post-peak residual deficit area, calculated as \code{AUC.total - AUC.load}.}
#'   \item{duration.twd.equiv_h}{Numeric; equivalent duration of the event at maximum TWD, \code{AUC.total / max.twd}.}
#'   \item{max.twd.std}{Numeric; \code{max.twd} standardized by the selected TWD reference (default 1 mm, tree mean of \code{Avg.twd}, tree maximum of \code{Avg.twd}, or a user-defined numeric value); used in \code{ABr.value.raw}.}
#'   \item{twd.reference}{Numeric; TWD reference (mm) used to standardize \code{Avg.twd} and \code{max.twd}.}
#'   \item{twd.reference.method}{Character; method used to define \code{twd.reference}.}
#'   \item{twd.average.standardized}{Numeric; \code{Avg.twd} divided by \code{twd_reference}; with the default reference of \code{1}, this is equal to \code{Avg.twd} expressed relative to one TWD measurement unit.}
#'   \item{duration.twd.days}{Numeric; direct phase duration scaled by \code{ABr.duration.reference_h}; with the default reference of 24 h, this is duration in days.}
#'   \item{loading.duration_h}{Numeric; duration from phase start to \code{Max.twd.time}.}
#'   \item{recovery.duration_h}{Numeric; duration from \code{Max.twd.time} to phase end.}
#'   \item{slope.load.twd}{Numeric; loading slope of TWD, \code{max.twd / loading.duration_h}. Larger values indicate faster shrinkage or deficit loading.}
#'   \item{slope.recovery.twd}{Numeric; recovery slope of TWD, \code{max.twd / recovery.duration_h}. Larger values indicate faster recovery.}
#'   \item{slope.load.twd.std}{Numeric; \code{slope.load.twd} standardized by the mean loading slope, unless \code{slope_load_reference} is supplied.}
#'   \item{slope.recovery.twd.std}{Numeric; \code{slope.recovery.twd} standardized by the mean recovery slope, unless \code{slope_recovery_reference} is supplied.}
#'   \item{recovery.slowness.std}{Numeric; inverse standardized recovery slope, \code{1 / slope.recovery.twd.std}. Larger values indicate slower recovery.}
#'   \item{slope.stress.std}{Numeric; combined stress slope, \code{sqrt(slope.load.twd.std * recovery.slowness.std)}. If either separate slope cannot be estimated because the maximum occurs at the event boundary, the function falls back internally to standardized total-event slope.}
#'   \item{ABr.beta.event}{Numeric; fixed duration exponent used for ABr in the peak-weighted formulation.}
#'   \item{ABr.duration.reference_h}{Numeric; reference duration in hours used to scale direct phase duration before applying beta.}
#'   \item{ABr.duration.factor}{Numeric; \code{duration.twd.days^ABr.beta.event}.}
#'   \item{ABr.value.raw}{Numeric; peak-weighted event-level ABr burden for TWD phases, \code{twd.average.standardized * max.twd.std * ABr.duration.factor}. Use this column (not the log-compressed \code{ABr.value}) when summing or averaging ABr over several events. \code{NA} for GRO.}
#'   \item{ABr.value.pct}{Numeric; percentage-scaled ABr value, \code{100 * ABr.value.raw}.}
#'   \item{ABr.value.log1p}{Numeric; log-transformed percentage-scaled ABr value, calculated as \code{log10(1 + ABr.value.pct)}, useful for plotting strongly right-skewed event burdens.}
#'   \item{Avg.twd, STD.twd}{Numeric; mean and standard deviation of TWD in the phase.}
#'   \item{DOY}{Integer; day-of-year for the phase start.}
#' }
#'
#' @section Column definitions (ZG_drought):
#' The \code{ZG_drought} table is returned only when
#' \code{drought_indices = TRUE}. It contains one row per calendar day.
#' \describe{
#'   \item{Tree}{Character or integer; dendrometer series identifier based on
#'   \code{TreeNum}.}
#'   \item{DATE}{\code{Date}; calendar day represented by the row.}
#'   \item{Year, Month, DOY}{Integer; calendar year, month, and day-of-year.}
#'   \item{MDS}{Numeric; maximum daily shrinkage in mm, calculated as the
#'   difference between the pre-dawn maximum stem radius and the midday minimum
#'   stem radius, \code{predawn_dm_max - midday_dm_min}.}
#'   \item{MDSmax}{Numeric; reference maximum daily shrinkage in mm. By default,
#'   this is the \code{mds_probability} quantile, usually 0.99, of valid MDS
#'   values within \code{season_months}.}
#'   \item{MDSnorm}{Numeric; normalized maximum daily shrinkage,
#'   \code{MDS / MDSmax}.}
#'   \item{TWDpredawn}{Numeric; pre-dawn tree water deficit in mm, calculated
#'   from the selected \code{predawn_hours} window.}
#'   \item{TWDnorm}{Numeric; normalized pre-dawn tree water deficit,
#'   \code{TWDpredawn / MDSmax}.}
#'   \item{TWDmidday}{Numeric; midday tree water deficit in mm, calculated
#'   from the selected \code{midday_hours} window.}
#'   \item{TWDnorm_midday}{Numeric; normalized midday tree water deficit,
#'   \code{TWDmidday / MDSmax}.}
#'   \item{TWDdaily_min, TWDdaily_max}{Numeric; minimum and maximum TWD observed
#'   during the calendar day.}
#'   \item{TWDnorm_daily_max}{Numeric; maximum daily TWD normalized by
#'   \code{MDSmax}.}
#'   \item{predawn_dm_max}{Numeric; maximum dendrometer value observed within
#'   \code{predawn_hours}.}
#'   \item{midday_dm_min}{Numeric; minimum dendrometer value observed within
#'   \code{midday_hours}.}
#'   \item{n_obs}{Integer; number of valid observations available for the day.}
#'   \item{n_predawn}{Integer; number of observations within the pre-dawn
#'   window.}
#'   \item{n_midday}{Integer; number of observations within the midday window.}
#'   \item{MDSmax_probability}{Numeric; probability used to estimate
#'   \code{MDSmax}.}
#'   \item{MDSmax_n}{Integer; number of seasonal MDS values used to estimate
#'   \code{MDSmax}.}
#'   \item{season_months}{Character; comma-separated list of months used for
#'   estimating \code{MDSmax}.}
#' }
#'
#' @examples
#' \donttest{
#' library(dendRoAnalyst)
#' data(gf_nepa17)
#'
#' # Minimal example (no smoothing)
#' zg <- phase.zg(df = gf_nepa17[1:600, ], TreeNum = 1)
#' head(zg$ZG_cycle, 5)
#' head(zg$ZG_phase, 5)
#' head(zg$ZG_drought, 5)
#'
#' # The same series recorded in micrometres gives the same ABr values
#' gf_um <- gf_nepa17[1:600, ]
#' gf_um[, -1] <- gf_um[, -1] * 1000
#' zg_um <- phase.zg(df = gf_um, TreeNum = 1, measurement_unit = "um")
#' all.equal(zg$ZG_cycle$ABr.value, zg_um$ZG_cycle$ABr.value)
#'
#' # With smoothing (e.g., 6 hours) to reduce short flips
#' zg6 <- phase.zg(df = gf_nepa17[1:600, ], TreeNum = 1, smoothing = 6)
#' subset(zg6$ZG_cycle, Phases == 1L)[1:5, c("Start", "End", "Duration_h", "max.twd",
#'   "Avg.twd", "twd.average.standardized", "duration.twd.days", "ABr.value.raw")]
#' }
#'
#' @importFrom lubridate ymd_hms ymd yday
#' @importFrom dplyr mutate rename select
#' @importFrom tibble tibble
#' @importFrom stats median sd na.exclude
#' @importFrom moments kurtosis
#'
#' @export
phase.zg <- function(df,
                     TreeNum,
                     smoothing = NULL,
                     measurement_unit = c("mm", "um", "cm"),
                     beta = 1,
                     abr_adaptive_beta = FALSE,
                     abr_duration_reference_h = 24,
                     twd_reference = 1,
                     max_twd_reference = NULL,
                     twd_max_reference = NULL,
                     slope_load_reference = NULL,
                     slope_recovery_reference = NULL,
                     drought_indices = TRUE,
                     predawn_hours = c(0, 6),
                     midday_hours = c(10, 16),
                     season_months = 5:10,
                     mds_probability = 0.99,
                     min_mds_n = 30) {

  Duration_h <- NULL

  if (TreeNum > (ncol(df) - 1)) {
    stop("The tree number is not valid for the provided dataset.")
  }

  measurement_unit <- match.arg(measurement_unit)
  # factor converting the input unit to mm
  unit_to_mm <- switch(measurement_unit, mm = 1, um = 1e-3, cm = 10)

  if (!is.numeric(beta) || length(beta) != 1 || is.na(beta) || beta < 0) {
    stop("beta must be a single non-negative numeric value.")
  }

  if (!is.logical(abr_adaptive_beta) || length(abr_adaptive_beta) != 1 || is.na(abr_adaptive_beta)) {
    stop("abr_adaptive_beta must be TRUE or FALSE.")
  }

  if (isTRUE(abr_adaptive_beta)) {
    warning(
      "abr_adaptive_beta is retained for backward compatibility but is not used ",
      "in the peak-weighted ABr formula. ABr.value uses the fixed beta ",
      "exponent with direct phase duration; loading/recovery slope columns are returned as diagnostics.",
      call. = FALSE
    )
  }

  if (!is.numeric(abr_duration_reference_h) || length(abr_duration_reference_h) != 1 ||
      is.na(abr_duration_reference_h) || abr_duration_reference_h <= 0) {
    stop("abr_duration_reference_h must be a single positive numeric value.")
  }

  twd_reference_missing <- missing(twd_reference)

  if ((!is.null(max_twd_reference) || !is.null(twd_max_reference)) &&
      !twd_reference_missing) {
    stop("Use twd_reference only; max_twd_reference and twd_max_reference are deprecated aliases.")
  }

  if (!is.null(max_twd_reference) && !is.null(twd_max_reference)) {
    stop("Use only one deprecated alias: max_twd_reference or twd_max_reference, not both.")
  }

  if (!is.null(max_twd_reference)) {
    warning("max_twd_reference is deprecated; use twd_reference instead.", call. = FALSE)
    twd_reference <- max_twd_reference
  }

  if (!is.null(twd_max_reference)) {
    warning("twd_max_reference is deprecated; use twd_reference instead.", call. = FALSE)
    twd_reference <- twd_max_reference
  }

  valid_twd_reference_keywords <- c("tree_mean", "mean", "tree_max", "max")

  if (!is.null(twd_reference)) {
    if (is.character(twd_reference)) {
      if (length(twd_reference) != 1 ||
          is.na(twd_reference) ||
          !(tolower(twd_reference) %in% valid_twd_reference_keywords)) {
        stop("twd_reference must be NULL, a single positive numeric value, or one of: 'tree_mean', 'mean', 'tree_max', 'max'.")
      }
      twd_reference <- tolower(twd_reference)
    } else if (is.numeric(twd_reference)) {
      if (length(twd_reference) != 1 || is.na(twd_reference) || twd_reference <= 0) {
        stop("twd_reference must be NULL, a single positive numeric value, or one of: 'tree_mean', 'mean', 'tree_max', 'max'.")
      }
    } else {
      stop("twd_reference must be NULL, a single positive numeric value, or one of: 'tree_mean', 'mean', 'tree_max', 'max'.")
    }
  }

  if (!is.null(slope_load_reference) &&
      (!is.numeric(slope_load_reference) || length(slope_load_reference) != 1 ||
       is.na(slope_load_reference) || slope_load_reference <= 0)) {
    stop("slope_load_reference must be NULL or a single positive numeric value.")
  }

  if (!is.null(slope_recovery_reference) &&
      (!is.numeric(slope_recovery_reference) || length(slope_recovery_reference) != 1 ||
       is.na(slope_recovery_reference) || slope_recovery_reference <= 0)) {
    stop("slope_recovery_reference must be NULL or a single positive numeric value.")
  }

  if (!is.logical(drought_indices) || length(drought_indices) != 1 || is.na(drought_indices)) {
    stop("drought_indices must be TRUE or FALSE.")
  }

  validate_hour_window <- function(x, name) {
    if (!is.numeric(x) || length(x) != 2 || any(is.na(x)) ||
        any(x < 0) || any(x > 24) || x[1] == x[2]) {
      stop(name, " must be a numeric vector of length two with values between 0 and 24.")
    }
    invisible(TRUE)
  }

  validate_hour_window(predawn_hours, "predawn_hours")
  validate_hour_window(midday_hours, "midday_hours")

  if (!is.numeric(season_months) || length(season_months) == 0 ||
      any(is.na(season_months)) || any(season_months < 1) || any(season_months > 12)) {
    stop("season_months must contain month numbers between 1 and 12.")
  }

  if (!is.numeric(mds_probability) || length(mds_probability) != 1 ||
      is.na(mds_probability) || mds_probability <= 0 || mds_probability >= 1) {
    stop("mds_probability must be a single numeric value between 0 and 1.")
  }

  if (!is.numeric(min_mds_n) || length(min_mds_n) != 1 ||
      is.na(min_mds_n) || min_mds_n < 1) {
    stop("min_mds_n must be a positive numeric value.")
  }

  # -------------------------------------------------------
  # Helpers
  # -------------------------------------------------------
  parse_time_dm <- function(x) {
    if (inherits(x, "POSIXct")) return(as.POSIXct(x))
    if (inherits(x, "Date")) return(as.POSIXct(x))

    out <- suppressWarnings(lubridate::ymd_hms(x, quiet = TRUE))
    if (all(is.na(out))) {
      out_date <- suppressWarnings(lubridate::ymd(x, quiet = TRUE))
      if (!all(is.na(out_date))) {
        out <- as.POSIXct(out_date)
      }
    }
    if (all(is.na(out))) {
      out <- suppressWarnings(as.POSIXct(x))
    }
    out
  }

  cummax_na <- function(x) {
    out <- rep(NA_real_, length(x))
    current_max <- NA_real_

    for (i in seq_along(x)) {
      if (!is.na(x[i])) {
        if (is.na(current_max)) {
          current_max <- x[i]
        } else {
          current_max <- max(current_max, x[i])
        }
      }
      out[i] <- current_max
    }
    out
  }

  phase_cal_zg <- function(y) {
    all_max <- cummax_na(y)
    phases <- rep(NA_integer_, length(y))

    ok <- !is.na(y) & !is.na(all_max)
    phases[ok & y == all_max] <- 2L
    phases[ok & y <  all_max] <- 1L

    phases
  }

  reso_den <- function(input_time) {
    time1 <- as.POSIXct(input_time)
    dmin <- diff(as.numeric(time1)) / 60
    dmin <- dmin[is.finite(dmin) & dmin > 0]

    if (length(dmin) == 0) {
      warning("Could not infer temporal resolution from the time column.")
      return(NA_real_)
    }

    uniq <- unique(round(dmin, 6))
    if (length(uniq) > 1) {
      warning(
        "The temporal resolution of the dendrometer data is not fully consistent. ",
        "Results may be affected if the time series contains irregular spacing or missing intervals."
      )
    }

    stats::median(dmin)
  }

  trapz_time <- function(time_vec, value_vec) {
    if (length(time_vec) < 2 || length(value_vec) < 2) return(0)

    xh <- as.numeric(difftime(time_vec, time_vec[1], units = "hours"))
    keep <- is.finite(xh) & !is.na(value_vec)
    xh <- xh[keep]
    yv <- value_vec[keep]

    if (length(xh) < 2) return(0)

    sum(diff(xh) * (yv[-1] + yv[-length(yv)]) / 2)
  }

  hour_decimal <- function(time_vec) {
    lt <- as.POSIXlt(time_vec)
    lt$hour + lt$min / 60 + lt$sec / 3600
  }

  in_hour_window <- function(hour_value, window) {
    start <- window[1]
    end <- window[2]
    if (start < end) {
      hour_value >= start & hour_value <= end
    } else {
      hour_value >= start | hour_value <= end
    }
  }

  safe_min <- function(x) {
    x <- x[is.finite(x)]
    if (length(x) == 0) NA_real_ else min(x)
  }

  safe_max <- function(x) {
    x <- x[is.finite(x)]
    if (length(x) == 0) NA_real_ else max(x)
  }

  calculate_drought_indices_zg <- function(zg_phase, tree_name) {
    if (!all(c("TIME", "dm", "TWD") %in% names(zg_phase))) {
      stop("ZG_phase must contain TIME, dm, and TWD columns for drought-index calculation.")
    }

    if (nrow(zg_phase) == 0) {
      return(tibble::tibble(
        Tree = character(),
        DATE = as.Date(character()),
        Year = integer(),
        Month = integer(),
        DOY = integer(),
        MDS = numeric(),
        MDSmax = numeric(),
        MDSnorm = numeric(),
        TWDpredawn = numeric(),
        TWDnorm = numeric()
      ))
    }

    phase <- zg_phase
    phase$DATE <- as.Date(phase$TIME)
    split_phase <- split(phase, phase$DATE)

    daily_list <- lapply(names(split_phase), function(dd) {
      x <- split_phase[[dd]]
      hd <- hour_decimal(x$TIME)
      predawn <- in_hour_window(hd, predawn_hours)
      midday <- in_hour_window(hd, midday_hours)

      predawn_dm_max <- safe_max(x$dm[predawn])
      midday_dm_min <- safe_min(x$dm[midday])
      mds_value <- predawn_dm_max - midday_dm_min
      if (!is.finite(mds_value) || mds_value < 0) mds_value <- NA_real_

      tibble::tibble(
        Tree = tree_name,
        DATE = as.Date(dd),
        Year = as.integer(format(as.Date(dd), "%Y")),
        Month = as.integer(format(as.Date(dd), "%m")),
        DOY = lubridate::yday(as.Date(dd)),
        MDS = mds_value,
        TWDpredawn = safe_min(x$TWD[predawn]),
        TWDmidday = safe_max(x$TWD[midday]),
        TWDdaily_min = safe_min(x$TWD),
        TWDdaily_max = safe_max(x$TWD),
        predawn_dm_max = predawn_dm_max,
        midday_dm_min = midday_dm_min,
        n_obs = nrow(x),
        n_predawn = sum(predawn, na.rm = TRUE),
        n_midday = sum(midday, na.rm = TRUE)
      )
    })

    daily <- dplyr::bind_rows(daily_list)

    valid_mds <- daily$MDS[
      is.finite(daily$MDS) & daily$MDS > 0 & daily$Month %in% season_months
    ]

    mdsmax <- if (length(valid_mds) == 0) {
      NA_real_
    } else {
      as.numeric(stats::quantile(valid_mds, probs = mds_probability, na.rm = TRUE, names = FALSE))
    }

    if (length(valid_mds) > 0 && length(valid_mds) < min_mds_n) {
      warning(
        "Only ", length(valid_mds), " valid seasonal MDS values were available for MDSmax. ",
        "The MDSmax estimate may be unstable."
      )
    }

    daily$MDSmax <- mdsmax
    daily$MDSmax_probability <- mds_probability
    daily$MDSmax_n <- length(valid_mds)
    daily$season_months <- paste(season_months, collapse = ",")

    daily$MDSnorm <- if (is.finite(mdsmax) && mdsmax > 0) daily$MDS / mdsmax else NA_real_
    daily$TWDnorm <- if (is.finite(mdsmax) && mdsmax > 0) daily$TWDpredawn / mdsmax else NA_real_
    daily$TWDnorm_midday <- if (is.finite(mdsmax) && mdsmax > 0) daily$TWDmidday / mdsmax else NA_real_
    daily$TWDnorm_daily_max <- if (is.finite(mdsmax) && mdsmax > 0) daily$TWDdaily_max / mdsmax else NA_real_

    daily[, c(
      "Tree", "DATE", "Year", "Month", "DOY",
      "MDS", "MDSmax", "MDSnorm",
      "TWDpredawn", "TWDnorm", "TWDmidday", "TWDnorm_midday",
      "TWDdaily_min", "TWDdaily_max", "TWDnorm_daily_max",
      "predawn_dm_max", "midday_dm_min",
      "n_obs", "n_predawn", "n_midday",
      "MDSmax_probability", "MDSmax_n", "season_months"
    )]
  }

  phase_stats_zg <- function(dm_data, y_class) {

    gro_crv <- cummax_na(dm_data$dm)
    twd_crv <- gro_crv - dm_data$dm

    n <- nrow(dm_data)
    prev_y <- c(NA_integer_, y_class[-n])
    next_y <- c(y_class[-1], NA_integer_)

    start_idx <- which(!is.na(y_class) & (is.na(prev_y) | y_class != prev_y))
    end_idx   <- which(!is.na(y_class) & (is.na(next_y) | y_class != next_y))

    if (length(start_idx) == 0) {
      out_cycle <- tibble::tibble(
        Tree = character(),
        Phases = integer(),
        Start = as.POSIXct(character()),
        End = as.POSIXct(character()),
        Duration_h = numeric(),
        DOY = integer(),
        Magnitude = numeric(),
        rate = numeric(),
        max.twd = numeric(),
        Max.twd.time = as.POSIXct(character()),
        Avg.twd = numeric(),
        STD.twd = numeric(),
        AUC.load = numeric(),
        AUC.total = numeric(),
        AUC.recovery = numeric(),
        duration.twd.equiv_h = numeric(),
        duration.twd.equiv_days = numeric(),
        duration.twd.days = numeric(),
        max.twd.std = numeric(),
        twd.average.standardized = numeric(),
        loading.duration_h = numeric(),
        recovery.duration_h = numeric(),
        slope.load.twd = numeric(),
        slope.recovery.twd = numeric(),
        slope.load.twd.std = numeric(),
        slope.recovery.twd.std = numeric(),
        recovery.slowness.std = numeric(),
        slope.stress.std = numeric(),
        ABr.beta.event = numeric(),
        ABr.duration.reference_h = numeric(),
        ABr.duration.factor = numeric(),
        ABr.value.raw = numeric(),
        ABr.value = numeric(),
        ABr.value.pct = numeric(),
        ABr.value.log1p = numeric()
      )

      out_phase <- dm_data %>%
        dplyr::mutate(
          Phases = y_class,
          TWD = twd_crv,
          GRO = gro_crv
        )

      return(list(out_cycle, tibble::as_tibble(out_phase)))
    }

    ph <- y_class[start_idx]
    strt_t <- dm_data$TIME[start_idx]

    # End is the boundary time (start of next phase), last phase ends at last timestamp
    boundary_idx <- pmin(end_idx + 1L, n)
    end_t <- dm_data$TIME[boundary_idx]

    dur_h <- as.numeric(difftime(end_t, strt_t, units = "hours"))

    # Growth magnitude over each non-overlapping phase segment
    magn <- rep(NA_real_, length(start_idx))
    gro_idx <- which(ph == 2L)
    if (length(gro_idx) > 0) {
      magn[gro_idx] <- gro_crv[end_idx[gro_idx]] - gro_crv[start_idx[gro_idx]]
    }

    rate <- rep(NA_real_, length(magn))
    ok_rate <- !is.na(magn) & !is.na(dur_h) & dur_h > 0
    rate[ok_rate] <- magn[ok_rate] * 1000 / dur_h[ok_rate]

    max_values <- rep(NA_real_, length(start_idx))
    max_time   <- rep(as.POSIXct(NA), length(start_idx))
    avg_twd    <- rep(NA_real_, length(start_idx))
    std_twd    <- rep(NA_real_, length(start_idx))
    auc_load   <- rep(NA_real_, length(start_idx))
    auc_total  <- rep(NA_real_, length(start_idx))
    auc_recovery <- rep(NA_real_, length(start_idx))
    duration_twd_equiv_h <- rep(NA_real_, length(start_idx))
    duration_twd_equiv_days <- rep(NA_real_, length(start_idx))
    duration_twd_days <- rep(NA_real_, length(start_idx))
    max_twd_std <- rep(NA_real_, length(start_idx))
    twd_average_std <- rep(NA_real_, length(start_idx))
    loading_duration_h <- rep(NA_real_, length(start_idx))
    recovery_duration_h <- rep(NA_real_, length(start_idx))
    slope_load_twd <- rep(NA_real_, length(start_idx))
    slope_recovery_twd <- rep(NA_real_, length(start_idx))
    slope_load_twd_std <- rep(NA_real_, length(start_idx))
    slope_recovery_twd_std <- rep(NA_real_, length(start_idx))
    recovery_slowness_std <- rep(NA_real_, length(start_idx))
    slope_stress_std <- rep(NA_real_, length(start_idx))
    slope_total_twd <- rep(NA_real_, length(start_idx))
    slope_total_twd_std <- rep(NA_real_, length(start_idx))
    abr_beta_event <- rep(NA_real_, length(start_idx))
    abr_duration_factor <- rep(NA_real_, length(start_idx))
    abr_value  <- rep(NA_real_, length(start_idx))
    abr_value_pct <- rep(NA_real_, length(start_idx))

    twd_idx <- which(ph == 1L)

    if (length(twd_idx) > 0) {
      for (k in twd_idx) {
        rng <- start_idx[k]:end_idx[k]
        twd_seg <- twd_crv[rng]
        time_seg <- dm_data$TIME[rng]

        if (!all(is.na(twd_seg))) {
          mx <- max(twd_seg, na.rm = TRUE)
          max_values[k] <- mx

          # last time of the maximum within phase
          wmx <- which(twd_seg == mx)
          max_time[k] <- time_seg[max(wmx)]

          avg_twd[k] <- mean(twd_seg, na.rm = TRUE)
          std_twd[k] <- stats::sd(twd_seg, na.rm = TRUE)
          peak_pos <- max(wmx)
          load_times <- c(strt_t[k], time_seg[seq_len(peak_pos)])
          load_vals  <- c(0, twd_seg[seq_len(peak_pos)])
          total_times <- c(strt_t[k], time_seg, end_t[k])
          total_vals  <- c(0, twd_seg, 0)

          auc_load[k] <- trapz_time(load_times, load_vals)
          auc_total[k] <- trapz_time(total_times, total_vals)

          if (!is.na(auc_total[k]) && !is.na(auc_load[k])) {
            auc_recovery[k] <- auc_total[k] - auc_load[k]
          }

          if (!is.na(max_values[k]) && max_values[k] > 0 && !is.na(auc_total[k])) {
            duration_twd_equiv_h[k] <- auc_total[k] / max_values[k]
          }

          if (!is.na(max_values[k]) && max_values[k] > 0) {
            loading_duration_h[k] <- as.numeric(difftime(max_time[k], strt_t[k], units = "hours"))
            recovery_duration_h[k] <- as.numeric(difftime(end_t[k], max_time[k], units = "hours"))

            if (!is.na(loading_duration_h[k]) && is.finite(loading_duration_h[k]) && loading_duration_h[k] > 0) {
              slope_load_twd[k] <- max_values[k] / loading_duration_h[k]
            }

            if (!is.na(recovery_duration_h[k]) && is.finite(recovery_duration_h[k]) && recovery_duration_h[k] > 0) {
              slope_recovery_twd[k] <- max_values[k] / recovery_duration_h[k]
            }

            if (!is.na(dur_h[k]) && is.finite(dur_h[k]) && dur_h[k] > 0) {
              slope_total_twd[k] <- max_values[k] / dur_h[k]
            }
          }


        }
      }
    }

    # -------------------------------------------------------
    # Peak-weighted ABr calculation
    # -------------------------------------------------------
    valid_twd_abr <- ph == 1L &
      !is.na(max_values) & is.finite(max_values) & max_values > 0 &
      !is.na(avg_twd) & is.finite(avg_twd) & avg_twd >= 0 &
      !is.na(dur_h) & is.finite(dur_h) & dur_h > 0

    if (is.null(twd_reference) ||
        (is.character(twd_reference) && twd_reference %in% c("tree_mean", "mean"))) {
      twd_ref_used <- if (any(valid_twd_abr)) mean(avg_twd[valid_twd_abr], na.rm = TRUE) else NA_real_
      twd_ref_method_used <- "tree_mean_avg_twd"
    } else if (is.character(twd_reference) && twd_reference %in% c("tree_max", "max")) {
      twd_ref_used <- if (any(valid_twd_abr)) max(avg_twd[valid_twd_abr], na.rm = TRUE) else NA_real_
      twd_ref_method_used <- "tree_max_avg_twd"
    } else {
      twd_ref_used <- twd_reference
      twd_ref_method_used <- "user_defined"
    }

    valid_load_ref <- valid_twd_abr &
      !is.na(slope_load_twd) & is.finite(slope_load_twd) & slope_load_twd > 0

    slope_load_ref_used <- if (is.null(slope_load_reference)) {
      if (any(valid_load_ref)) mean(slope_load_twd[valid_load_ref], na.rm = TRUE) else NA_real_
    } else {
      slope_load_reference
    }

    valid_recovery_ref <- valid_twd_abr &
      !is.na(slope_recovery_twd) & is.finite(slope_recovery_twd) & slope_recovery_twd > 0

    slope_recovery_ref_used <- if (is.null(slope_recovery_reference)) {
      if (any(valid_recovery_ref)) mean(slope_recovery_twd[valid_recovery_ref], na.rm = TRUE) else NA_real_
    } else {
      slope_recovery_reference
    }

    valid_total_ref <- valid_twd_abr &
      !is.na(slope_total_twd) & is.finite(slope_total_twd) & slope_total_twd > 0

    slope_total_ref_used <- if (any(valid_total_ref)) {
      mean(slope_total_twd[valid_total_ref], na.rm = TRUE)
    } else {
      NA_real_
    }

    if (any(valid_twd_abr) && is.finite(twd_ref_used) && twd_ref_used > 0) {
      max_twd_std[valid_twd_abr] <- max_values[valid_twd_abr] / twd_ref_used
      twd_average_std[valid_twd_abr] <- avg_twd[valid_twd_abr] / twd_ref_used
    }

    if (any(valid_load_ref) && is.finite(slope_load_ref_used) && slope_load_ref_used > 0) {
      slope_load_twd_std[valid_load_ref] <- slope_load_twd[valid_load_ref] / slope_load_ref_used
    }

    if (any(valid_recovery_ref) && is.finite(slope_recovery_ref_used) && slope_recovery_ref_used > 0) {
      slope_recovery_twd_std[valid_recovery_ref] <- slope_recovery_twd[valid_recovery_ref] / slope_recovery_ref_used
    }

    valid_recovery_slowness <- valid_twd_abr &
      !is.na(slope_recovery_twd_std) & is.finite(slope_recovery_twd_std) & slope_recovery_twd_std > 0
    recovery_slowness_std[valid_recovery_slowness] <- 1 / slope_recovery_twd_std[valid_recovery_slowness]

    valid_stress <- valid_twd_abr &
      !is.na(slope_load_twd_std) & is.finite(slope_load_twd_std) & slope_load_twd_std > 0 &
      !is.na(recovery_slowness_std) & is.finite(recovery_slowness_std) & recovery_slowness_std > 0
    slope_stress_std[valid_stress] <- sqrt(slope_load_twd_std[valid_stress] * recovery_slowness_std[valid_stress])

    if (any(valid_total_ref) && is.finite(slope_total_ref_used) && slope_total_ref_used > 0) {
      slope_total_twd_std[valid_total_ref] <- slope_total_twd[valid_total_ref] / slope_total_ref_used
    }

    # Fallback for edge cases where peak TWD occurs exactly at the first or last
    # timestamp of a phase and separate loading/recovery slopes cannot be estimated.
    missing_stress <- valid_twd_abr &
      (is.na(slope_stress_std) | !is.finite(slope_stress_std) | slope_stress_std <= 0) &
      !is.na(slope_total_twd_std) & is.finite(slope_total_twd_std) & slope_total_twd_std > 0
    slope_stress_std[missing_stress] <- slope_total_twd_std[missing_stress]

    if (any(valid_twd_abr)) {
      # Peak-weighted ABr.
      # This replaces the former AUC-equivalent-duration formula. The new default
      # uses standardized average TWD, standardized maximum TWD, and direct phase duration:
      #   ABr.value = twd.average.standardized * max.twd.std * (Duration_h / abr_duration_reference_h)^beta
      # The default twd_reference = 1 (mm) gives:
      #   ABr.value = Avg.twd * max.twd * (Duration_h / abr_duration_reference_h)^beta
      # With beta = 1 and abr_duration_reference_h = 24, duration is in days.
      # AUC.total and equivalent-duration columns are still returned as diagnostics,
      # but they no longer control ABr.value.
      abr_beta_event[valid_twd_abr] <- beta
      duration_twd_days[valid_twd_abr] <- dur_h[valid_twd_abr] / abr_duration_reference_h

      has_equiv_days <- valid_twd_abr &
        !is.na(duration_twd_equiv_h) & is.finite(duration_twd_equiv_h) & duration_twd_equiv_h >= 0
      duration_twd_equiv_days[has_equiv_days] <- duration_twd_equiv_h[has_equiv_days] / abr_duration_reference_h

      ok_abr <- valid_twd_abr &
        !is.na(twd_average_std) & is.finite(twd_average_std) & twd_average_std >= 0 &
        !is.na(max_twd_std) & is.finite(max_twd_std) & max_twd_std > 0 &
        !is.na(duration_twd_days) & is.finite(duration_twd_days) & duration_twd_days >= 0 &
        !is.na(abr_beta_event) & is.finite(abr_beta_event) & abr_beta_event >= 0

      # both TWD terms are standardized by the same reference
      abr_duration_factor[ok_abr] <- duration_twd_days[ok_abr]^abr_beta_event[ok_abr]
      abr_value[ok_abr] <- twd_average_std[ok_abr] * max_twd_std[ok_abr] * abr_duration_factor[ok_abr]
      abr_value_pct[ok_abr] <- 100 * abr_value[ok_abr]
    }

    abr_value_log1p <- ifelse(
      !is.na(abr_value_pct) & is.finite(abr_value_pct) & abr_value_pct >= 0,
      log10(1 + abr_value_pct),
      NA_real_
    )

    dy <- lubridate::yday(strt_t)

    out_cycle <- tibble::tibble(
      Tree = tree_name,
      Phases = ph,
      Start = strt_t,
      End = end_t,
      Duration_h = dur_h,
      DOY = dy,
      Magnitude = magn,
      rate = rate,
      max.twd = max_values,
      Max.twd.time = as.POSIXct(max_time, origin = "1970-01-01", tz = attr(dm_data$TIME, "tzone")),
      Avg.twd = avg_twd,
      STD.twd = std_twd,
      AUC.load = auc_load,
      AUC.total = auc_total,
      AUC.recovery = auc_recovery,
      duration.twd.equiv_h = duration_twd_equiv_h,
      duration.twd.equiv_days = duration_twd_equiv_days,
      duration.twd.days = duration_twd_days,
      max.twd.std = max_twd_std,
      twd.reference = ifelse(ph == 1L, twd_ref_used, NA_real_),
      twd.reference.method = ifelse(ph == 1L, twd_ref_method_used, NA_character_),
      twd.average.standardized = twd_average_std,
      loading.duration_h = loading_duration_h,
      recovery.duration_h = recovery_duration_h,
      slope.load.twd = slope_load_twd,
      slope.recovery.twd = slope_recovery_twd,
      slope.load.twd.std = slope_load_twd_std,
      slope.recovery.twd.std = slope_recovery_twd_std,
      recovery.slowness.std = recovery_slowness_std,
      slope.stress.std = slope_stress_std,
      ABr.beta.event = abr_beta_event,
      ABr.duration.reference_h = ifelse(!is.na(abr_value), abr_duration_reference_h, NA_real_),
      ABr.duration.factor = abr_duration_factor,
      ABr.value.raw = abr_value,
      ABr.value = abr_value_log1p,
      ABr.value.pct = abr_value_pct,
      ABr.value.log1p = abr_value_log1p
    ) %>%
      dplyr::filter(Duration_h >= 0)

    attr(out_cycle, "ABr.method") <- "average_standardized_peak_weighted_duration"
    attr(out_cycle, "ABr.beta") <- beta
    attr(out_cycle, "ABr.duration.reference_h") <- abr_duration_reference_h
    attr(out_cycle, "ABr.twd.reference") <- twd_ref_used
    attr(out_cycle, "ABr.twd.reference.method") <- twd_ref_method_used
    attr(out_cycle, "ABr.formula") <- "(Avg.twd / twd_reference) * (max.twd / twd_reference) * (Duration_h / abr_duration_reference_h)^beta; TWD in mm; default twd_reference = 1"
    attr(out_cycle, "measurement_unit_input") <- measurement_unit
    attr(out_cycle, "ABr.slope.load.twd.reference") <- slope_load_ref_used
    attr(out_cycle, "ABr.slope.recovery.twd.reference") <- slope_recovery_ref_used
    attr(out_cycle, "ABr.slope.total.twd.reference_fallback") <- slope_total_ref_used


    out_phase <- dm_data %>%
      dplyr::mutate(
        Phases = y_class,
        TWD = twd_crv,
        GRO = gro_crv
      )

    list(out_cycle, tibble::as_tibble(out_phase))
  }

  # -------------------------------------------------------
  # Prepare input
  # -------------------------------------------------------
  df[[1]] <- parse_time_dm(df[[1]])
  if (all(is.na(df[[1]]))) {
    stop("Could not parse the first column as date-time.")
  }

  tree_name <- names(df)[TreeNum + 1]

  dm_data <- tibble::as_tibble(df) %>%
    dplyr::select(c(1, TreeNum + 1)) %>%
    dplyr::rename(
      TIME = 1,
      dm = 2
    )

  # all calculations are carried out in mm
  if (!is.numeric(dm_data$dm)) {
    stop("The selected dendrometer series must be numeric.")
  }
  dm_data$dm <- dm_data$dm * unit_to_mm

  r.denro <- reso_den(dm_data$TIME)
  sf <- smoothing

  # -------------------------------------------------------
  # Optional smoothing for phase assignment
  # -------------------------------------------------------
  if (is.null(sf)) {
    y_for_phase <- dm_data$dm
  } else {
    if (!is.numeric(sf) || length(sf) != 1 || is.na(sf) || sf < 1 || sf > 24) {
      stop("smoothing must be a single numeric value between 1 and 24 hours.")
    }

    warning(
      paste0(
        "You are applying smoothing to raw dendrometer data. ",
        "The smoothing value is ", sf, " hour(s)."
      )
    )

    y_for_phase <- smooth_dm(
      time = dm_data$TIME,
      dm = dm_data$dm,
      method = "median_mean",
      window_hours = sf
    )
  }

  # -------------------------------------------------------
  # Classify phases and summarize
  # -------------------------------------------------------
  y_class <- phase_cal_zg(y_for_phase)
  ot <- phase_stats_zg(dm_data, y_class)

  out <- list(
    ZG_cycle = ot[[1]],
    ZG_phase = ot[[2]]
  )

  if (drought_indices) {
    out$ZG_drought <- calculate_drought_indices_zg(ot[[2]], tree_name = tree_name)
  }

  class(out) <- "ZG_output"
  out
}
