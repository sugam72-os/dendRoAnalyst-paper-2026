.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to dendRoAnalyst ", utils::packageVersion(pkgname), "!\n",
          "To check the changes in this version, see vignette(\"NEWS\", package = \"dendRoAnalyst\").\n",
          "Please see the publication: Aryal, S., Haeusser, M., Griessinger, J., Fan, Z., and Braeuning, A. (2020). 'dendRoAnalyst': A tool for processing and analysing dendrometer data. Dendrochronologia, 64, 125772.")
}
