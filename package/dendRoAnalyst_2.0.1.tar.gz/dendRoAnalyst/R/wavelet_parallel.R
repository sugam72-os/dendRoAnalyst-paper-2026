# Internal helper: Monte Carlo significance of WaveletComp analyses on several cores
#
# WaveletComp estimates each p-value as the proportion of n.sim surrogate series
# whose statistic is at least as large as the observed one. The simulations can
# therefore be split into batches that run in parallel; the weighted mean of the
# batch p-values equals the p-value of a single run with all simulations.

#' @keywords internal
#' @noRd
.dm_wavelet_pvals_parallel <- function(fun, args, n_sim, n_cores, pval_fields) {
  n_cores <- max(1L, min(as.integer(n_cores), as.integer(n_sim)))
  n_k <- rep(n_sim %/% n_cores, n_cores)
  rest <- n_sim %% n_cores
  if (rest > 0) n_k[seq_len(rest)] <- n_k[seq_len(rest)] + 1L

  cl <- parallel::makeCluster(n_cores)
  on.exit(parallel::stopCluster(cl), add = TRUE)
  # independent, reproducible random-number streams (seeded from the R session)
  parallel::clusterSetRNGStream(cl, iseed = sample.int(.Machine$integer.max, 1))

  batch <- function(nk, wave_fun, wave_args, fields) {
    wave_args$n.sim <- nk
    wave_args$make.pval <- TRUE
    wave_args$verbose <- FALSE
    res <- do.call(wave_fun, wave_args)
    res[fields]
  }
  # do not ship the calling frame (data, cluster object) to the workers
  environment(batch) <- baseenv()

  res <- parallel::parLapply(cl, n_k, batch, wave_fun = fun, wave_args = args, fields = pval_fields)

  out <- lapply(pval_fields, function(f) {
    Reduce(`+`, Map(function(r, nk) r[[f]] * nk, res, n_k)) / n_sim
  })
  names(out) <- pval_fields
  out
}
