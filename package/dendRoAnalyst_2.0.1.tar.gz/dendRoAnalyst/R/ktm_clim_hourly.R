#' @title Hourly climate data for Kathmandu derived from ERA5-Land
#'
#' @description
#' Hourly near-surface climate data for Kathmandu, Nepal, extracted from the
#' Copernicus Climate Change Service (C3S) ERA5-Land reanalysis. The dataset is
#' included to demonstrate climate–dendrometer workflows in
#' \pkg{dendRoAnalyst}, including joining hourly climate data with dendrometer
#' observations, event-based analyses, and wavelet-based analyses.
#'
#' @format A data frame with 17513 hourly observations (1 January 2017, 07:00,
#'   to 31 December 2018, 23:00 NPT) and 5 variables:
#' \describe{
#'   \item{\code{TIME}}{POSIXct; date-time stamp of the hourly observation in
#'     Nepal Standard Time (NPT, UTC+05:45), stored with the time zone
#'     \code{"Asia/Kathmandu"}.}
#'   \item{\code{temp}}{Air temperature in degree Celsius.}
#'   \item{\code{prec}}{Precipitation total of the hour ending at \code{TIME},
#'     in millimetres.}
#'   \item{\code{VPD}}{Vapour pressure deficit in kPa.}
#'   \item{\code{RH}}{Relative humidity in percent.}
#' }
#'
#' @details
#' \code{ktm_clim_hourly} contains a single-location hourly climate time series
#' for Kathmandu derived from ERA5-Land. ERA5-Land is a global land-surface
#' reanalysis produced by replaying the land component of ERA5 at enhanced
#' spatial resolution and is widely used for land-surface and ecohydrological
#' applications.
#'
#' ERA5-Land is provided at full UTC hours, and its precipitation is
#' accumulated from 00 UTC onwards. For this dataset (since version 2.0.1),
#' precipitation was converted to hourly totals, and all variables were
#' transferred to full hours of Nepal Standard Time, the time zone of the
#' example dendrometer data (\code{\link{nepa17}}, \code{\link{gf_nepa17}}).
#' Because NPT is 5 h 45 min ahead of UTC, each NPT hour lies between two UTC
#' hours: temperature, VPD, and relative humidity were interpolated linearly,
#' and hourly precipitation totals were split between the two overlapping UTC
#' hours in proportion to the overlap (0.75 and 0.25), which preserves the
#' precipitation totals. Climate and dendrometer data must be in the same time
#' zone before they are joined.
#'
#' Like other reanalysis products in complex terrain, ERA5-Land overestimates
#' precipitation in the Kathmandu Valley: the 2017 total of this dataset
#' (about 3090 mm) is about twice the station total of \code{\link{ktm_rain17}}
#' (1458 mm). The data are therefore suitable for demonstrating the workflows
#' but not for climatological interpretation.
#'
#' This dataset is intended as an example climate input for
#' \pkg{dendRoAnalyst}. It can be used, for example, with functions that join
#' dendrometer and climate data, calculate phase-climate relations, run event
#' analyses, or perform wavelet and wavelet-coherence analyses.
#'
#' Users should check the exact temporal coverage of the object in their local
#' installation, for example with:
#' \preformatted{
#' range(ktm_clim_hourly$TIME)
#' }
#'
#' @source
#' Extracted from the Copernicus Climate Change Service (C3S) Climate Data Store
#' ERA5-Land reanalysis product:
#'
#' Muñoz-Sabater, J. (2019). ERA5-Land hourly data from 1950 to present.
#' Copernicus Climate Change Service (C3S) Climate Data Store (CDS).
#'
#' @references
#' Muñoz-Sabater, J., Dutra, E., Agustí-Panareda, A., Albergel, C.,
#' Arduini, G., Balsamo, G., Boussetta, S., Choulga, M., Harrigan, S.,
#' Hersbach, H., Martens, B., Miralles, D. G., Piles, M.,
#' Rodríguez-Fernández, N. J., Zsoter, E., Buontempo, C., and Thépaut, J.-N.
#' (2021). ERA5-Land: a state-of-the-art global reanalysis dataset for land
#' applications. \emph{Earth System Science Data}, 13, 4349--4383.
#'
"ktm_clim_hourly"
