#' @title Dendrometer data from Kathmandu version 2
#' @description The data of \code{\link{nepa}} with the time stamp split into
#'   separate columns: dendrometer data from two Chir pine (\emph{Pinus
#'   roxburghii}) trees in Kathmandu, Nepal, recorded with band dendrometers at
#'   hourly resolution from May 2016 to December 2017. The time columns give
#'   Nepal Standard Time (NPT, UTC+05:45).
#' @format A data frame with 14543 rows and 8 variables:
#' \describe{
#'   \item{\code{year}}{numeric year of data recording}
#'   \item{\code{month}}{numeric months of data recording}
#'   \item{\code{day}}{numeric days of data recording}
#'   \item{\code{hours}}{numeric hours of data recording}
#'   \item{\code{minutes}}{numeric minutes of data recording}
#'   \item{\code{seconds}}{numeric seconds of data recording}
#'   \item{\code{T2}}{double reading for first tree (mm)}
#'   \item{\code{T3}}{double reading for second tree (mm)}
#'}
"nepa2"
