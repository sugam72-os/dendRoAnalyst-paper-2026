# Internal time-zone helpers ----------------------------------------------------
#
# Dendrometer and climate data are processed in the time zone stored in their
# POSIXct time stamps. base::as.Date() converts POSIXct values to dates in UTC
# unless a time zone is given, which would assign observations recorded in
# local time to the wrong calendar day. This internal version is used within
# the package namespace and converts POSIXct values with the time zone of the
# object; inputs without a time zone attribute are treated as UTC, as before.

#' @keywords internal
#' @noRd
as.Date <- function(x, ...) {
  if (inherits(x, "POSIXct") && !("tz" %in% ...names())) {
    return(base::as.Date(x, tz = .dm_tz(x), ...))
  }
  base::as.Date(x, ...)
}

#' Time zone stored in a POSIXct vector, or "UTC" if none is stored
#' @keywords internal
#' @noRd
.dm_tz <- function(x, default = "UTC") {
  tz <- attr(x, "tzone")
  if (is.null(tz) || length(tz) == 0 || is.na(tz[1]) || !nzchar(tz[1])) default else tz[1]
}

#' Convert to POSIXct, keeping the time zone of POSIXct input
#'
#' POSIXct values that already carry a time zone are returned unchanged, so
#' that local time stamps are not relabelled as UTC. Other inputs are converted
#' with \code{tz}.
#' @keywords internal
#' @noRd
.dm_as_posixct_keep_tz <- function(x, tz = "UTC") {
  if (inherits(x, "POSIXct")) {
    if (identical(.dm_tz(x, default = ""), "")) return(as.POSIXct(x, tz = tz))
    return(x)
  }
  if (inherits(x, "POSIXlt")) {
    tz_lt <- attr(x, "tzone")
    if (!is.null(tz_lt) && length(tz_lt) > 0 && nzchar(tz_lt[1])) return(as.POSIXct(x))
  }
  as.POSIXct(x, tz = tz)
}
