# Suppress R CMD check notes for tidy evaluation and internally created columns.
# This file is safe to keep in R/globals.R.

utils::globalVariables(c(
  "Tree",
  "TIME",
  "dm",
  "Phases",
  "rate",
  "GRO",
  "TWD",
  "Variable",
  "Value",
  "Period",
  "Start_plot",
  "End_plot",
  "Phases_plot",
  "Tree_plot",
  "metric_plot",
  "Duration_h",
  "Start_DOY",
  "Start_Year",
  "xmin",
  "xmax",
  ".phase_run"
))
