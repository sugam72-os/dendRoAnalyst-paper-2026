#' Launch the dendRoAnalyst Shiny workbench
#'
#' Follow the package workflow interactively, select a working directory, and
#' save analysis objects as RDS files for reuse in later sessions. CSV exports
#' are also produced for tables. The app is intended for local desktop use.
#' @param working_dir Existing directory containing input files and results.
#' @param launch.browser Whether to open the app in a web browser.
#' @param ... Additional arguments passed to [shiny::runApp()].
#' @return The value returned by [shiny::runApp()], invisibly.
#' @export
#' @examples
#' \dontrun{
#' dendroanalyst()
#' dendroanalyst(working_dir = "D:/dendrometer_data")
#' }
dendroanalyst <- function(working_dir = getwd(), launch.browser = TRUE, ...) {
  required <- c("shiny", "bslib", "DT", "shinyFiles")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop("Install the app dependencies first: install.packages(c(",
         paste(sprintf('"%s"', missing), collapse = ", "), "))", call. = FALSE)
  }
  if (!is.character(working_dir) || length(working_dir) != 1L ||
      is.na(working_dir) || !dir.exists(working_dir)) {
    stop("working_dir must be an existing directory.", call. = FALSE)
  }
  app <- system.file("shiny", "dendroAnalystApp", package = "dendRoAnalyst")
  if (!nzchar(app)) stop("The installed Shiny app could not be found.", call. = FALSE)
  old <- options(dendRoAnalyst.working_dir = normalizePath(working_dir, winslash = "/"))
  on.exit(options(old), add = TRUE)
  invisible(shiny::runApp(app, launch.browser = launch.browser, ...))
}
