#' @title Dendrometer data of Kathmandu for 2017 with gap filled
#' @description Gap-filled version of \code{\link{nepa17}}: dendrometer data
#'   from two Chir pine (\emph{Pinus roxburghii}) trees in Kathmandu, Nepal,
#'   recorded with band dendrometers at hourly resolution in 2017. The values
#'   are stem circumference variations in mm.
#' @format A data frame with 8760 rows and 3 variables:
#' \describe{
#'   \item{\code{Time}}{POSIXct; time of data recording in Nepal Standard Time
#'     (NPT, UTC+05:45), stored with the time zone \code{"Asia/Kathmandu"}.}
#'   \item{\code{T2}}{double; reading of the first tree (mm).}
#'   \item{\code{T3}}{double; reading of the second tree (mm).}
#'}
#' @details The dendrometers recorded local time. Since version 2.0.1, the
#'   time stamps are POSIXct values with the time zone \code{"Asia/Kathmandu"};
#'   in earlier versions they were character strings that were parsed as UTC.
#'   The example climate data \code{\link{ktm_clim_hourly}} are given in the
#'   same time zone.
"gf_nepa17"
