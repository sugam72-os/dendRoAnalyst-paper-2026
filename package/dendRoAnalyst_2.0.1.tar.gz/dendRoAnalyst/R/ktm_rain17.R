#' @title Daily rainfall data of Kathmandu for 2017.
#' @description This file contains daily rainfall data of Kathmandu. The source of this data is 'Government of Nepal, Department of Hydrology and Meteorology'.
#' @format A data frame with 365 rows and 2 variables:
#' \describe{
#'   \item{\code{TIME}}{Date in YYYY-MM-DD format.}
#'   \item{\code{rainfall}}{double rainfall in millimeters}
#'}
#' @source Department of Hydrology and Meteorology, Government of Nepal
#'   (dhm.gov.np).
"ktm_rain17"
