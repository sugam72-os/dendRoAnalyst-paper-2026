testthat::test_that("phase boxplots retain events and separate calendar years", {
  cycle <- data.frame(Start=as.POSIXct(c(rep("2017-01-05",5),rep("2018-01-05",5)),tz="UTC"),
                      ABr.value=c(1:5,11:15), Magnitude=c(1:5,11:15), Phases=1, Tree="T2")
  for(kind in c("ZG","SC")) {
    x <- structure(setNames(list(cycle),paste0(kind,"_cycle")),class=paste0(kind,"_output"))
    stat <- if(kind=="ZG") "ABr.value" else "Magnitude"
    p <- plot(x,type="boxplot",stat=stat,temporal="monthly")
    testthat::expect_equal(nrow(p$data),10)
    built <- ggplot2::ggplot_build(p)$data[[1]]
    testthat::expect_equal(built$middle,c(3,13))
    testthat::expect_equal(built$lower,c(2,12))
    testthat::expect_equal(built$upper,c(4,14))
    testthat::expect_equal(nrow(plot(x,type="boxplot",stat=stat,temporal="monthly",Year=2018)$data),5)
    testthat::expect_error(plot(x,type="boxplot",stat="typo"),"requested statistic")
  }
})
