testthat::test_that("scatter fits finite pairs from the selected table", {
  z <- structure(list(ZG_cycle=data.frame(a=c(1:5,NA), b=c(2,5,5,9,11,4)),
                      ZG_drought=data.frame(DATE=as.Date('2020-01-01')+0:4,a=1:5,b=c(2,5,5,9,11))),class='ZG_output')
  p <- plot(z,type='scatter',xvar='a',yvar='b',fit='linear')
  expected <- stats::lm(b~a,data=z$ZG_cycle)
  testthat::expect_equal(attr(p,'scatter_stats')$slope,unname(coef(expected)[2]))
  testthat::expect_equal(attr(p,'scatter_stats')$n,5)
  testthat::expect_equal(attr(p,'scatter_stats')$excluded,1)
  testthat::expect_equal(nrow(plot(z,type='scatter',source='ZG_drought',xvar='a',yvar='b',DOY=c(2,4))$data),3)
  testthat::expect_error(plot(z,type='scatter',xvar='missing',yvar='b'),'numeric columns')
  testthat::expect_error(plot(z,type='scatter',xvar='a',yvar='b',unexpected=1),'Unsupported')
})
