# Dependency-free checks of saved-result discovery and class preservation.
app <- file.path("inst", "shiny", "dendroAnalystApp", "app.R")
if (file.exists(app)) {
  env <- new.env(parent = globalenv())
  expressions <- parse(app)
  helpers <- c("%||%", "null_if_blank", "normalize_user_path",
               "wd_file_choices", "load_r_object_file")
  for (expr in expressions) {
    if (is.call(expr) && identical(expr[[1]], as.name("<-")) &&
        as.character(expr[[2]]) %in% helpers) eval(expr, env)
  }
  env$app_supported_ext <- c("csv", "rds")
  folder <- tempfile("dendro-app-test-")
  dir.create(folder)
  dir.create(file.path(folder, "dendroAnalyst_results"))
  object <- structure(list(ZG_phase = data.frame(Time = as.POSIXct("2020-01-01", tz = "UTC"), value = 1)), class = "ZG_output")
  path <- file.path(folder, "dendroAnalyst_results", "phase.rds")
  saveRDS(object, path)
  choices <- env$wd_file_choices(folder)
  stopifnot(file.path("dendroAnalyst_results", "phase.rds") %in% choices)
  stopifnot(identical(object, env$load_r_object_file(path)))
  cat("Saved-result discovery and RDS class round-trip passed.\n")
}
